<?php


$conn= mysqli_connect("localhost","root","","projectcanada");

// $nconn= new mysqli("localhost","detsconl_projectdb","detsconl_projectdb","detsconl_projectdb");
$nconn= new mysqli("localhost","root","","projectcanada");

// if(!$conn){die("Connection faile".mysqli_connect_error($conn));}else{
//     echo "connected";
//     }
?>

    