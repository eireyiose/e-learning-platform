<?php 
require"../system/class.php";

$db= new System();

$db->Logout("index.php");
?>