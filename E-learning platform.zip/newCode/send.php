<?hp


echo "hi";

?>