<footer>

  <div class="footerArea">


  <div class="row text-center">
          <div class="col-sm-4">
          <h4>CONTACT US</h4>
          <p>Email:info@gmail.com</p>
          <p>Phone:07019999999</p>
          <p>Address:location</p>
          </div>

          <div class="col-sm-4">
          <h4>QUICK LINKS</h4>
          <p><a href="index.html">Home</a></p>
          <p><a href="About.html">About</a></p>
          <p><a href="Registration.html">Registration</a></p>
          <p><a href="login.html">Login</a></p>
          </div>
         
          <div class="col-sm-4">
          <h4>FOLLOW US</h4>
          <p><a href=""><i class="bi bi-facebook"></i></a></p>
          <p><a href=""><i class="bi bi-youtube"></i></a></p>
          <p><a href=""><i class="bi bi-instagram"></i></a></p>
        </div>
</div>


<hr style="color:white; margin-right:100px; margin-left:100px;">

<div class="row">
  <div class="col-sm-12">
<p class=""><i class="bi bi-c-circle"></i> 2025 CodeOnline. All rights reserved</p>
</div>
</div>

</div>
</footer>