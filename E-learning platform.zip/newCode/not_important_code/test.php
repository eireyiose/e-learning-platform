<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Document</title>
</head>
<body>
	<!-- <form action="check.php" method="post"> -->
		<div class="form-group">
		<textarea name="code" required cols="40" rows="3" id="user-code"></textarea>
			
		</div>
		<div class="form-group">
			<button type="submit" id="run-code">Ckeck</button>
		</div>
		<div class="result"id="output"></div>
		<div id="result-correct"></div>
	<!-- </form> -->
	<script>

const outputDiv = document.getElementById('output');
const userCodeTextarea = document.getElementById('user-code');
const runCodeButton = document.getElementById('run-code');

runCodeButton.addEventListener('click', () => {
    const userCode = userCodeTextarea.value;
    const expectedOutput = 'x is greater than 5';
    const numberToCheck = 10;

    // Run the user's code
    try {
        eval(userCode);
    } catch (error) {
        outputDiv.innerText = `Error: ${error.message}`;
        return;
    }

    // Check if the output matches the expected output
    const actualOutput = outputDiv.innerText;
    if (actualOutput === expectedOutput) {
        outputDiv.innerText = 'Correct!';
    } else {
        outputDiv.innerText = `Incorrect. Expected:\n${expectedOutput}`;
    }
});

// Function to log output to the div
function logOutput(message) {
    outputDiv.innerText += `${message}\n`;
}

// Override console.log to log to the div
console.log = logOutput;

	</script>
</body>
</html>