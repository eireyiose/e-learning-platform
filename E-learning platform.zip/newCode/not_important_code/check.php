<?php 
extract($_POST);
$code=trim($code);
$code=strtolower($code);
$code=preg_replace('/[\(\)]/','',$code);
$code=preg_replace('/\s+/',' ',$code);
$if_array= array("var x=8;if(x>5){console.log('x is greater than 5');}","let x=8;if(x>5){console.log('x is greater than 5');}","const x=8;if(x>5){console.log('x is greater than 5');}",
"var y=1;if(y<=10){console.log('y is less than or equal to 10');}
	","let y=1;if(y<=10){console.log('y is less than or equal to 10');}","const y=1;if(y<=10){console.log('y is less than or equal to 10');}");
if(in_array($code,$if_array)){
	echo 1;
}else{
	echo 0;
}