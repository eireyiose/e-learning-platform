
<?php

// Configuration
$db_host = 'localhost';
$db_username = 'detsconl_projectdb';
$db_password = 'detsconl_projectdb';
$db_name = 'detsconl_projectdb';

// Connect to database
$conn = new mysqli($db_host, $db_username, $db_password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Receive user code

$user_code = $_POST['code'];
//var
//echo $user_code;
// Prepare query
$stmt = $conn->query("SELECT * FROM code WHERE correct1='$user_code' OR correct2='$user_code' OR correct3='$user_code'");


// Execute query

if($stmt->num_rows>0){
echo 1;
}



else{
    echo 0;
}

// If no match is found, display an error message

echo $stmt->error;
// Close statement and connection
$stmt->close();
$conn->close();

?>
