
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tables</title>
    
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    
    
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-6 offset-md-3">
                <div class="card">
                    <div class="card-header">
                        <h4>Question Tables</h4>
                    </div>
                    <form action="viewQuestions.php" method="post">
                    <div class="card-body">
                    <div class="form-group">
                        <select class="form-control" id="table-select" name="table">
                        <option value="">chose questions</option>
                            <option value="if_questions">If Questions</option>
                            <option value="questions">Variable Questions</option>
                            <option value="loop_questions">Loop Questions</option>
                        </select>
                        </div>
                        <div id="table-content">
                        <button type="submit" class="btn btn-primary" name="view">
                        Viw Question
                        </button>
                        </view>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>
</html>

