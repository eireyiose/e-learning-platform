
<?php

// Configuration
$db_host = 'localhost';
$db_username = 'detsconl_projectdb';
$db_password = 'detsconl_projectdb';
$db_name = 'detsconl_projectdb';

// Connect to database
$conn = new mysqli($db_host, $db_username, $db_password, $db_name);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Receive user code
$user_code = $_POST['user_code'];

// Prepare query
$stmt = $conn->prepare("SELECT correct1, correct2, correct3 FROM code WHERE id='$id' AND topic='if'");

// Execute query
$stmt->execute();

// Get result
$result = $stmt->get_result();

// Check if code matches any of the correct codes
while ($row = $result->fetch_assoc()) {
    if ($user_code == $row['correct1'] || $user_code == $row['correct2'] || $user_code == $row['correct3']) {
        echo 1;
        exit;
    }else{
    echo 0;
    }
}

// If no match is found, display an error message


// Close statement and connection
$stmt->close();
$conn->close();

?>
