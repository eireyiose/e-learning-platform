<style>
    h1,h2,h3,h4{
        text-transform:uppercase;
    }
    code{
        padding:30px;
        margin:50px 0 0 0;
        /* width:400px; */
        height:400px;
    }
    pre{
        background-color:black;
        color:white;

    }
    li{
        list-style-type:none;
        padding:10px;
        
    }
    a{
        text-decoration:none;
        color:white;
    }
</style>
<div class="col-md-10">
    <h2 class="text-center">IF STAMENT</h2>
    <p>
    An if statement is a programming construct that 
    allows a program to make decisions based on conditions.
     It a selection statement that controls the flow of a program by
      executing different blocks of code depending on whether a
       condition is true or false.
       <br/> <br><br>
       <p>
        <h4>TYPES OF IF STATEMENTS</h4>
        <hr>
        <ol>
            <li>Simple if statement</li>
            <li> if else statement</li>
            <li>if else if statement</li>
            <li>nested else if statement</li>
            <li>switch case statement</li>
            <li>Tenary Operator</li>
        </ol>
       </p><hr>
       <h4 class="text-upper" style="text-transfom:uppercase;">

           Structure of a simple if statement
       </h4>
    IF (CONDITION IS TRUE)
    <br/>
<p style="margin: 0 0 0 50px;">STATEMENT TO EXECUTE</p>
<hr>

</p>
   
    <hr>
    <p>
        <h4>sample code of a simple if statement with javascript</h4> <br><br><br>
        
        <pre>
        <code>
           // simple if statement
        let a =100;
        let b=200;
       if(a==b){
            
            console.log(`the value of ${a} is equal to the value of ${b}`); 
        }
    </code>
</pre>
</p>
<br><br><br>
<hr>
    <p> 
        
        <h4>sample code of an if else statement </h4> <br><br><br>
        <pre>

            <code>
                
            var a=10, b=30;
            if(a==b){
            
                
                cout<<"a is equal to b"<<;
            }else{
                cout<<"a is not equal to b";
            }
            
        
    </code>
</pre>
</p>
<hr>
<p>




<pre>
<code>
    #this is an if statement in python
    a=1
    b=2
    if(a==b):
        print(f"{a} and {b} are equal")
</code>
</pre>
    </p>
    <hr>
    <p>
            
    <a href="profile.php?url=practice">Practice What You Have Earnt So Far</a>
    </p>
    
    
    
    
    <style>

main {
  max-width: 800px;
  margin: 2em auto;
  padding: 2em;
  background-color: #fff;
  border: 1px solid #ddd;
  box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
}

.question-container {
  margin-bottom: 2em;
}

.options {
  margin-top: 1em;
}

button {
  padding: 1em 2em;
  margin: 0.5em;
  border: none;
  border-radius: 0.5em;
  background-color: #4CAF50;
  color: #fff;
  cursor: pointer;
  
}

button:hover {
  background-color: #3e8e41;
}

#submit-btn {
  background-color: #333;
  color: #fff;
}
.hidden {
display:none;

}
#result {
  margin-top: 2em;
  font-size: 1.5em;
  font-weight: bold;
}

#next{
color:red;
}
</style>
<a href="ifexercise.php" class="btn btn-success">Start test</a>
<main class="hi">
<div class="question-container hidden">


<?php
require "ifq.php";
//session_start();
//$_SESSION["exist"])){

//"<p class='bg-danger text-white text-enter'>"

//.$_SESSION['exist']."</p>";

//}

?>

<a href="profile.php?url=ifstatements2" id="next">Next</a>

</div>
</main>
<script>
 
 document.querySelector(".start-test").addEventListener("click", function (){
 // alert ("hi");
  
 if(document.querySelector(".question-container").classList.contains("hidden")){
  
 document.querySelector(".question-container").classList.toggle("hidden");
 }
  
  document.querySelector(".start-test").scrollIntoView({
  behavior: 'smooth',
  block: 'center'
});
  
  
  });
  
  
  
  
  
  
</script>
	
	</p>
	<p>
		
	<a href="profile.php?url=practice">Practice What You Have Earnt So Far</a>
	</p>
</div>
    
</div>